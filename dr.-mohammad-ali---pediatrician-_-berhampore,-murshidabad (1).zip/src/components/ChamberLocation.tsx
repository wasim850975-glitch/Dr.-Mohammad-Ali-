import React from 'react';
import { DOCTOR_DATA } from '../data/translations';
import { Language } from '../types';
import { MapPin, Phone, Clock, ExternalLink, Navigation } from 'lucide-react';

interface ChamberLocationProps {
  lang: Language;
}

export const ChamberLocation: React.FC<ChamberLocationProps> = ({ lang }) => {
  return (
    <section id="contact" className="py-16 md:py-20 bg-white border-b border-[#dce8eb] scroll-mt-16">
      <div className="max-w-[1160px] mx-auto px-5">
        {/* Section Head */}
        <div className="text-center max-w-[690px] mx-auto mb-11">
          <div className="inline-flex items-center justify-center gap-2 text-[#0d7180] font-extrabold text-xs tracking-[1.8px] uppercase mb-2">
            <span className="w-[20px] h-[2px] bg-[#d9a94b]" />
            <span>{lang === 'bn' ? 'চেম্বারের অবস্থান ও ছবি' : 'Chamber Location & Photo'}</span>
            <span className="w-[20px] h-[2px] bg-[#d9a94b]" />
          </div>

          <h2 className="text-[28px] sm:text-[38px] font-extrabold leading-[1.15] text-[#103b52] tracking-[-1px] my-2">
            {lang === 'bn' ? 'মিশন মেডিকেল সেন্টার, লালদিঘি' : 'Mission Medical Centre, Laldighi'}
          </h2>

          <p className="text-[15px] text-[#617582] mt-2 mb-0">
            {lang === 'bn'
              ? 'ডা. মহম্মদ আলির বহরমপুর চেম্বার। আসার আগে ফোনে বা হোয়াটসঅ্যাপে সিরিয়াল নিশ্চিত করুন।'
              : 'Dr. Mohammad Ali’s Baharampore chamber. Contact via phone or WhatsApp for appointment confirmation.'}
          </p>
        </div>

        {/* 3 Contact Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="p-5 sm:p-6 border border-[#dce8eb] rounded-[20px] bg-[#f9fcfe] shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-[#0d7180]/10 grid place-items-center text-[#0d7180] mb-3">
              <MapPin className="w-5 h-5" />
            </div>
            <b className="block text-[#103b52] text-sm mb-1 font-bold">
              {lang === 'bn' ? 'চেম্বারের ঠিকানা' : 'Chamber Address'}
            </b>
            <span className="text-[13px] text-[#55737d] leading-relaxed block">
              Mission Medical Centre, Laldighi, Baharampore, Murshidabad, West Bengal – 742101
            </span>
            <span className="inline-block mt-2 text-[11px] font-bold text-[#0d7180] bg-[#eaf6f5] px-2.5 py-0.5 rounded-full">
              Laldighi Landmark
            </span>
          </div>

          <div className="p-5 sm:p-6 border border-[#dce8eb] rounded-[20px] bg-[#f9fcfe] shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-[#0d7180]/10 grid place-items-center text-[#0d7180] mb-3">
              <Phone className="w-5 h-5" />
            </div>
            <b className="block text-[#103b52] text-sm mb-1 font-bold">
              {lang === 'bn' ? 'ফোন ও WhatsApp বুকিং' : 'Phone & WhatsApp Serial'}
            </b>
            <span className="text-[13px] text-[#55737d] block leading-relaxed">
              <a
                href={`tel:${DOCTOR_DATA.phone.replace(/\s+/g, '')}`}
                className="font-mono font-bold text-[#0d7180] hover:underline text-base block"
              >
                {DOCTOR_DATA.phone}
              </a>
              <span className="text-xs text-[#617582] mt-1 block">
                {lang === 'bn' ? 'সরাসরি কল বা WhatsApp করুন' : 'Direct Call or WhatsApp for tokens'}
              </span>
            </span>
          </div>

          <div className="p-5 sm:p-6 border border-[#dce8eb] rounded-[20px] bg-[#f9fcfe] shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-[#0d7180]/10 grid place-items-center text-[#0d7180] mb-3">
              <Clock className="w-5 h-5" />
            </div>
            <b className="block text-[#103b52] text-sm mb-1 font-bold">
              {lang === 'bn' ? 'চেম্বারের দিন ও সময়' : 'Visiting Schedule'}
            </b>
            <span className="text-[13px] text-[#55737d] leading-relaxed block">
              <strong className="text-[#103b52] font-bold">প্রতি রবিবার থেকে বৃহস্পতিবার</strong>
              <br />
              <span className="text-xs text-[#617582]">Sunday to Thursday (Regular)</span>
              <br />
              Morning: 10:00 AM – 02:00 PM
              <br />
              Evening: 05:30 PM – 09:00 PM
            </span>
          </div>
        </div>

        {/* 2-Column: Real Building Photo + Google Map Location */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
          {/* Real Chamber Exterior Photo */}
          <div className="border border-[#dce8eb] rounded-[22px] overflow-hidden bg-white shadow-xs flex flex-col justify-between">
            <div className="p-4 sm:p-5 border-b border-[#dce8eb] flex items-center justify-between bg-[#fafcfc]">
              <div className="flex items-center gap-2">
                <Navigation className="w-4 h-4 text-[#0d7180]" />
                <h3 className="font-bold text-[#103b52] text-sm sm:text-base">
                  {lang === 'bn' ? 'মিশন মেডিকেল সেন্টার ভবন (লালদিঘি)' : 'Mission Medical Centre Building'}
                </h3>
              </div>
              <span className="text-[11px] font-semibold text-[#0d7180] bg-[#eaf6f5] px-2.5 py-0.5 rounded-full">
                Real Photo
              </span>
            </div>

            <div className="relative flex-1 min-h-[300px] bg-slate-100 overflow-hidden group">
              <img
                src="/assets/aistudio/Vibrant_Kolkata_Medical_Centre_Alleyway_6774023e.png"
                alt="Mission Medical Centre Building Exterior - Laldighi, Baharampore"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 text-white">
                <span className="text-xs font-semibold block text-emerald-300">
                  মিশন মেডিকেল সেন্টার (Mission Medical Centre)
                </span>
                <span className="text-[11px] text-slate-200">
                  Laldighi, Baharampore — Signboard visible from main street
                </span>
              </div>
            </div>

            <div className="p-3.5 bg-white border-t border-[#dce8eb] text-xs text-[#617582] flex items-center justify-between">
              <span>{lang === 'bn' ? 'লালদিঘির কাছে ক্লিনিক ভবনটি অবস্থিত' : 'Located at Laldighi commercial zone'}</span>
              <span className="font-mono text-[#0d7180] font-bold">PIN 742101</span>
            </div>
          </div>

          {/* Interactive Google Map */}
          <div className="border border-[#dce8eb] rounded-[22px] overflow-hidden bg-[#edf4f5] shadow-xs flex flex-col justify-between">
            <div className="p-4 sm:p-5 border-b border-[#dce8eb] flex items-center justify-between bg-[#fafcfc]">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#0d7180]" />
                <h3 className="font-bold text-[#103b52] text-sm sm:text-base">
                  {lang === 'bn' ? 'Google Maps নেভিগেশন' : 'Live Google Map Location'}
                </h3>
              </div>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://www.google.com/maps/search/?api=1&query=Mission+Medical+Centre+Laldighi+Baharampur+Murshidabad+742101"
                className="text-xs font-bold text-[#0d7180] hover:underline flex items-center gap-1"
              >
                <span>{lang === 'bn' ? 'বড় ম্যাপে খুলুন' : 'Open in Maps'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div className="relative flex-1 min-h-[300px]">
              <iframe
                title="Google Maps Location - Mission Medical Centre Laldighi Baharampur"
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: '300px' }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src="https://maps.google.com/maps?q=Mission%20Medical%20Centre,%20Laldighi,%20Baharampur,%20Murshidabad,%20West%20Bengal%20742101&t=&z=15&ie=UTF8&iwloc=&output=embed"
                className="w-full h-full"
              />
            </div>

            <div className="p-3.5 bg-white border-t border-[#dce8eb] text-xs text-[#617582] flex items-center justify-between">
              <span>Mission Medical Centre, Laldighi, Baharampore</span>
              <a
                target="_blank"
                rel="noopener noreferrer"
                href="https://www.google.com/maps/dir/?api=1&destination=Mission+Medical+Centre+Laldighi+Baharampur"
                className="font-bold text-[#0d7180] hover:text-[#095d6b] flex items-center gap-1"
              >
                <span>{lang === 'bn' ? 'দিকনির্দেশ নিন (Directions) →' : 'Get Directions →'}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
