import React from 'react';
import { DOCTOR_DATA } from '../data/translations';
import { Language } from '../types';

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ lang, onToggleLang, onOpenBooking }) => {
  return (
    <>
      {/* Topbar matching reference */}
      <div className="bg-[#103b52] text-[#e8f5f7] text-[13px] py-2">
        <div className="max-w-[1160px] mx-auto px-5 flex justify-between items-center gap-3.5 flex-wrap">
          <span className="font-medium">
            {lang === 'bn'
              ? 'বহরমপুর, মুর্শিদাবাদে শিশু চিকিৎসা পরিষেবা · কলকাতা মেডিকেল কলেজ ও হাসপাতালে কর্মরত'
              : 'Pediatric care in Baharampore, Murshidabad · Kolkata Medical College & Hospital'}
          </span>
          <div className="flex items-center gap-3 text-xs">
            <span>Mission Medical Centre, Laldighi · 742101</span>
            <span className="text-teal-300">·</span>
            <a href={`tel:${DOCTOR_DATA.phone.replace(/\s+/g, '')}`} className="font-mono hover:text-white font-semibold">
              {DOCTOR_DATA.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Sticky Navigation */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#dce8eb]">
        <div className="max-w-[1160px] mx-auto px-5 h-[76px] flex items-center justify-between gap-5">
          {/* Brand mark and title */}
          <a href="#home" className="flex items-center gap-3 font-extrabold text-[#103b52] tracking-tight">
            <span className="w-[42px] h-[42px] rounded-[14px] bg-gradient-to-br from-[#0d7180] to-[#103b52] grid place-items-center text-white text-[23px] shrink-0 shadow-xs">
              ✚
            </span>
            <div>
              <span className="text-[17px] font-bold block leading-tight text-[#103b52]">
                {lang === 'bn' ? DOCTOR_DATA.nameBn : DOCTOR_DATA.name}
              </span>
              <small className="block text-[10px] tracking-[1.7px] text-[#617582] font-bold uppercase mt-0.5">
                {lang === 'bn' ? 'শিশু বিশেষজ্ঞ (PEDIATRICIAN)' : 'PEDIATRICIAN IN BAHARAMPORE'}
              </small>
            </div>
          </a>

          {/* Links */}
          <nav className="hidden md:flex items-center gap-6 text-[14px] font-medium text-[#49616d]">
            <a href="#home" className="hover:text-[#0d7180] transition-colors">
              {lang === 'bn' ? 'হোম' : 'Home'}
            </a>
            <a href="#about" className="hover:text-[#0d7180] transition-colors">
              {lang === 'bn' ? 'পরিচিতি' : 'About'}
            </a>
            <a href="#services" className="hover:text-[#0d7180] transition-colors">
              {lang === 'bn' ? 'পরিষেবা' : 'Services'}
            </a>
            <a href="#appointment" className="hover:text-[#0d7180] transition-colors">
              {lang === 'bn' ? 'অ্যাপয়েন্টমেন্ট' : 'Appointment'}
            </a>
            <a href="#contact" className="hover:text-[#0d7180] transition-colors">
              {lang === 'bn' ? 'যোগাযোগ ও মানচিত্র' : 'Contact'}
            </a>
          </nav>

          {/* Nav Actions */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onToggleLang}
              type="button"
              className="border border-[#dce8eb] bg-white rounded-full px-3.5 py-2 font-bold text-[#103b52] text-xs hover:bg-[#edf5fb] transition-colors cursor-pointer"
            >
              {lang === 'en' ? 'বাংলা' : 'English'}
            </button>

            <button
              onClick={onOpenBooking}
              type="button"
              className="hidden sm:inline-flex items-center justify-center gap-2 border-0 rounded-full px-5 py-2.5 bg-[#0d7180] hover:bg-[#095d6b] text-white font-bold text-xs cursor-pointer shadow-[0_8px_20px_rgba(13,113,128,0.18)] transition-all hover:-translate-y-0.5"
            >
              <span>{lang === 'bn' ? 'অ্যাপয়েন্টমেন্ট নিন' : 'Book Appointment'}</span>
            </button>
          </div>
        </div>
      </header>
    </>
  );
};
