import React from 'react';
import { DOCTOR_DATA } from '../data/translations';
import { Language } from '../types';
import { Award, Hospital, Calendar, Stethoscope } from 'lucide-react';

interface AboutDoctorProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const AboutDoctor: React.FC<AboutDoctorProps> = ({ lang, onOpenBooking }) => {
  return (
    <section id="about" className="py-16 md:py-20 bg-[#f7fbfc] border-b border-[#dce8eb] scroll-mt-16">
      <div className="max-w-[1160px] mx-auto px-5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          {/* Left Column: Official Poster of Dr. Mohammad Ali with Mission Medical Centre Branding */}
          <div className="lg:col-span-5">
            <div className="rounded-[26px] overflow-hidden border-2 border-[#dce8eb] shadow-[0_16px_40px_rgba(16,59,82,0.12)] bg-white relative group">
              <img
                src="/assets/aistudio/Caring_Today__Healthy_Tomorrow_cda3382f.png"
                alt="Dr. Mohammad Ali Official Chamber Poster - Mission Medical Centre"
                className="w-full h-auto object-cover transition-transform duration-300 group-hover:scale-[1.02]"
              />
              <div className="p-4 bg-white border-t border-[#dce8eb] flex items-center justify-between text-xs text-[#617582]">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-semibold text-[#103b52]">Mission Medical Centre Official Notice</span>
                </div>
                <span className="text-[11px] text-[#0d7180] font-bold">Laldighi</span>
              </div>
            </div>
          </div>

          {/* Right Column: About Details, Qualifications & Chamber Timings */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 text-[#0d7180] font-extrabold text-xs tracking-[1.8px] uppercase mb-2">
              <span className="w-[20px] h-[2px] bg-[#d9a94b]" />
              <span>{lang === 'bn' ? 'ডাক্তারের পরিচিতি ও যোগ্যতা' : 'About Dr. Mohammad Ali'}</span>
            </div>

            <h2 className="text-[28px] sm:text-[38px] font-extrabold leading-[1.15] text-[#103b52] tracking-[-1px] my-3">
              {lang === 'bn' ? 'ডা. মহম্মদ আলি — শিশু বিশেষজ্ঞ' : 'Dr. Mohammad Ali — Pediatrician'}
            </h2>

            {/* Doctor description */}
            <div className="text-[15px] sm:text-[16px] text-[#476373] leading-relaxed space-y-4 mb-6">
              <p>
                <strong>Dr. Mohammad Ali</strong> (ডা. মহম্মদ আলি) is a senior child specialist (Pediatrician) practicing at <strong>Mission Medical Centre, Laldighi, Baharampore</strong>. With <strong>20 years of clinical experience</strong>, he is attached to the premier <strong>Kolkata Medical College and Hospital</strong>.
              </p>
              <p>
                বহরমপুরের শিশু বিশেষজ্ঞ ডা. মহম্মদ আলি MBBS (Cal), MD (Pediatrics) এবং DM (Pediatric Intensive Care) ডিগ্রিধারী। নবজাতক থেকে কিশোর বয়স পর্যন্ত শিশুদের জ্বর, সর্দি-কাশি, শ্বাসকষ্ট ও অন্যান্য সাধারণ রোগের চিকিৎসা, নিয়মিত টিকাদান এবং শারীরিক বৃদ্ধি ও বিকাশের সার্বিক পরীক্ষা তিনি করে থাকেন।
              </p>
            </div>

            {/* Qualifications 4-card grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
              <div className="p-3.5 rounded-[14px] bg-[#eaf6f5] border border-[#d2ebe9] flex items-start gap-3">
                <Award className="w-5 h-5 text-[#0d7180] shrink-0 mt-0.5" />
                <div>
                  <b className="text-[13px] text-[#103b52] block font-bold">MBBS (Cal)</b>
                  <span className="text-xs text-[#55737d]">Calcutta Medical College & Hospital</span>
                </div>
              </div>

              <div className="p-3.5 rounded-[14px] bg-[#eaf6f5] border border-[#d2ebe9] flex items-start gap-3">
                <Stethoscope className="w-5 h-5 text-[#0d7180] shrink-0 mt-0.5" />
                <div>
                  <b className="text-[13px] text-[#103b52] block font-bold">MD (Pediatrics)</b>
                  <span className="text-xs text-[#55737d]">Specialized Child Healthcare</span>
                </div>
              </div>

              <div className="p-3.5 rounded-[14px] bg-[#eaf6f5] border border-[#d2ebe9] flex items-start gap-3">
                <Award className="w-5 h-5 text-[#0d7180] shrink-0 mt-0.5" />
                <div>
                  <b className="text-[13px] text-[#103b52] block font-bold">DM (Pediatric Intensive Care)</b>
                  <span className="text-xs text-[#55737d]">Super-specialty in Critical Pediatric Care</span>
                </div>
              </div>

              <div className="p-3.5 rounded-[14px] bg-[#eaf6f5] border border-[#d2ebe9] flex items-start gap-3">
                <Hospital className="w-5 h-5 text-[#0d7180] shrink-0 mt-0.5" />
                <div>
                  <b className="text-[13px] text-[#103b52] block font-bold">Kolkata Medical College</b>
                  <span className="text-xs text-[#55737d]">Active Hospital Attachment</span>
                </div>
              </div>
            </div>

            {/* Chamber Days Banner */}
            <div className="p-4 rounded-[16px] bg-white border border-[#dce8eb] mb-6 flex flex-wrap items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#edf6f7] grid place-items-center text-[#0d7180]">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-sm text-[#103b52] block">
                    {lang === 'bn' ? 'চেম্বারের দিন: প্রতি রবিবার থেকে বৃহস্পতিবার' : 'Chamber Days: Sunday to Thursday'}
                  </strong>
                  <span className="text-xs text-[#617582]">
                    Mission Medical Centre, Laldighi, Baharampore · PIN 742101
                  </span>
                </div>
              </div>
              <button
                onClick={onOpenBooking}
                type="button"
                className="inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 bg-[#0d7180] hover:bg-[#095d6b] text-white font-bold text-xs cursor-pointer shadow-xs transition-all hover:-translate-y-0.5"
              >
                <span>{lang === 'bn' ? 'সিরিয়াল বুক করুন →' : 'Book Serial →'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
