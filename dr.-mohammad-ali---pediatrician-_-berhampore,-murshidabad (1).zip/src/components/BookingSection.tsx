import React, { useState } from 'react';
import { DOCTOR_DATA } from '../data/translations';
import { Language, AppointmentData } from '../types';
import { MessageCircle, Printer, RotateCcw } from 'lucide-react';

interface BookingSectionProps {
  lang: Language;
}

export const BookingSection: React.FC<BookingSectionProps> = ({ lang }) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [formData, setFormData] = useState({
    parent: '',
    phone: '',
    age: '',
    date: todayStr,
    shift: 'morning' as 'morning' | 'evening',
    reason: 'General consultation',
    note: '',
  });

  const [submittedBooking, setSubmittedBooking] = useState<AppointmentData | null>(null);
  const [noticeMessage, setNoticeMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const parentVal = formData.parent.trim();
    const phoneVal = formData.phone.trim();
    const ageVal = formData.age.trim();
    const dateVal = formData.date;
    const shiftText = formData.shift === 'morning' ? 'Morning (10:00 AM - 02:00 PM)' : 'Evening (05:30 PM - 09:00 PM)';
    const reasonVal = formData.reason;
    const noteVal = formData.note.trim() || 'None';

    const randomToken = Math.floor(Math.random() * 20) + 5;
    const newBooking: AppointmentData = {
      id: 'MMC-' + Math.random().toString(36).substring(2, 7).toUpperCase(),
      childName: parentVal + "'s Child",
      childAge: ageVal,
      gender: 'male',
      guardianName: parentVal,
      phone: phoneVal,
      address: 'Baharampur',
      visitDate: dateVal,
      shift: formData.shift,
      reason: reasonVal,
      tokenNumber: randomToken,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setSubmittedBooking(newBooking);

    // Formulate WhatsApp message exactly per reference template
    const msg =
      `Appointment request for Dr. Mahammad Ali\n` +
      `Chamber: Mission Medical Centre, Laldighi, Baharampur\n` +
      `Days: Sunday to Thursday\n` +
      `Token: #${randomToken}\n` +
      `Parent/Guardian: ${parentVal}\n` +
      `Phone: ${phoneVal}\n` +
      `Child's age: ${ageVal}\n` +
      `Preferred date: ${dateVal} (${shiftText})\n` +
      `Reason: ${reasonVal}\n` +
      `Additional note: ${noteVal}\n` +
      `Please confirm availability.`;

    const encodedMsg = encodeURIComponent(msg);
    const waUrl = `https://wa.me/919093964188?text=${encodedMsg}`;

    setNoticeMessage(
      lang === 'bn'
        ? `আপনার অনুরোধ তৈরি হয়েছে (টোকেন #${randomToken})। হোয়াটসঅ্যাপে বার্তা পাঠানো হচ্ছে...`
        : `Your request is ready (Token #${randomToken}). Opening WhatsApp for +91 9093964188...`
    );

    // Open WhatsApp in new window
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="appointment" className="py-16 md:py-20 bg-[#f7fbfc] border-b border-[#dce8eb] scroll-mt-16">
      <div className="max-w-[1160px] mx-auto px-5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: .booking-info (5 cols) */}
          <div className="lg:col-span-5 bg-[#103b52] text-white rounded-[24px] p-7 sm:p-9 shadow-xs">
            <div className="text-[#a9d9d8] font-extrabold text-xs tracking-[1.8px] uppercase mb-2">
              {lang === 'bn' ? 'অ্যাপয়েন্টমেন্ট' : 'Appointments'}
            </div>

            <h2 className="text-[26px] sm:text-[32px] font-extrabold text-white leading-[1.2] tracking-tight my-2">
              {lang === 'bn' ? 'আপনার শিশুর দেখানোর সময় ঠিক করুন।' : "Plan your child's visit."}
            </h2>

            <p className="text-[#d1e4e9] text-[14px] leading-relaxed mt-2 mb-6">
              {lang === 'bn'
                ? 'অনলাইনে অ্যাপয়েন্টমেন্টের অনুরোধ পাঠান অথবা WhatsApp-এ যোগাযোগ করুন। ক্লিনিক থেকে সময় নিশ্চিত করা হবে।'
                : 'Send an appointment request online or contact the clinic on WhatsApp. The clinic will confirm your appointment.'}
            </p>

            <div className="space-y-4 pt-4 border-t border-white/10 text-[14px] text-[#e8f4f5]">
              <div className="flex items-start gap-3">
                <span className="text-lg">📍</span>
                <div>
                  <strong className="block text-white font-semibold">Mission Medical Centre</strong>
                  <span className="text-xs text-[#d1e4e9]">Laldighi, Baharampur, Murshidabad<br />West Bengal – 742101</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-lg">◷</span>
                <div>
                  <strong className="block text-white font-semibold">Sunday to Thursday</strong>
                  <span className="text-xs text-[#d1e4e9]">
                    Morning: 10:00 AM – 02:00 PM<br />
                    Evening: 05:30 PM – 09:00 PM
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-lg">☏</span>
                <div>
                  <strong className="block text-white font-semibold">Phone / WhatsApp Booking</strong>
                  <a href={`tel:${DOCTOR_DATA.phone.replace(/\s+/g, '')}`} className="font-mono text-sm text-teal-300 hover:underline">
                    {DOCTOR_DATA.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3 pt-2 border-t border-white/10 text-xs text-[#a9d9d8]">
                <span>🏥</span>
                <span>Attached with Kolkata Medical College & Hospital</span>
              </div>
            </div>
          </div>

          {/* Right Column: .formbox (7 cols) */}
          <div className="lg:col-span-7 bg-white border border-[#dce8eb] rounded-[24px] p-6 sm:p-8 shadow-[0_18px_50px_rgba(18,59,78,0.10)]">
            {submittedBooking ? (
              /* Token Slip Card */
              <div id="printable-token" className="space-y-4">
                <div className="flex items-start justify-between pb-3 border-b border-[#dce8eb]">
                  <div>
                    <span className="text-[11px] font-bold text-[#0d7180] bg-[#eaf6f5] px-2.5 py-0.5 rounded-full">
                      Chamber Token Issued
                    </span>
                    <h3 className="text-xl font-bold text-[#103b52] mt-1.5">
                      {lang === 'bn' ? DOCTOR_DATA.nameBn : DOCTOR_DATA.name}
                    </h3>
                    <div className="text-xs text-[#617582]">
                      MBBS (Cal), MD (Paediatrics), DM (PICU) · Mission Medical Centre
                    </div>
                  </div>

                  <div className="text-center bg-[#0d7180] text-white rounded-xl p-2.5 px-4">
                    <div className="text-[10px] uppercase font-bold text-teal-100">Token</div>
                    <div className="text-2xl font-bold font-mono">#{submittedBooking.tokenNumber}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs py-1">
                  <div>
                    <span className="text-[#617582] block text-[11px]">Parent / Guardian:</span>
                    <span className="font-bold text-[#103b52] text-sm">{submittedBooking.guardianName}</span>
                  </div>
                  <div>
                    <span className="text-[#617582] block text-[11px]">Child's Age:</span>
                    <span className="font-semibold text-[#103b52]">{submittedBooking.childAge}</span>
                  </div>
                  <div>
                    <span className="text-[#617582] block text-[11px]">Date & Shift:</span>
                    <span className="font-bold text-[#0d7180]">
                      {submittedBooking.visitDate} ({submittedBooking.shift === 'morning' ? 'Morning' : 'Evening'})
                    </span>
                  </div>
                  <div>
                    <span className="text-[#617582] block text-[11px]">Phone:</span>
                    <span className="font-mono font-semibold text-[#103b52]">{submittedBooking.phone}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[#617582] block text-[11px]">Reason for visit:</span>
                    <span className="font-medium text-[#103b52]">{submittedBooking.reason}</span>
                  </div>
                </div>

                <div className="p-3 bg-[#eaf6f5] rounded-xl text-xs text-[#176342] border border-[#bce2d8]">
                  <strong>✓ Notice:</strong> Your appointment request has been prepared and WhatsApp opened. The chamber desk will confirm your serial.
                </div>

                <div className="pt-2 flex flex-wrap gap-2.5">
                  <a
                    href={`https://wa.me/919093964188?text=${encodeURIComponent(
                      `Appointment Token #${submittedBooking.tokenNumber} for Dr. Mahammad Ali\nParent: ${submittedBooking.guardianName}\nPhone: ${submittedBooking.phone}\nChild Age: ${submittedBooking.childAge}\nDate: ${submittedBooking.visitDate}`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-[#168b58] hover:bg-[#126b44] text-white rounded-full text-xs font-bold transition-colors"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Open WhatsApp Again</span>
                  </a>

                  <button
                    onClick={() => window.print()}
                    type="button"
                    className="inline-flex items-center gap-1 px-4 py-2.5 bg-white border border-[#dce8eb] hover:bg-slate-50 text-[#103b52] rounded-full text-xs font-bold transition-colors cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print Slip</span>
                  </button>

                  <button
                    onClick={() => {
                      setSubmittedBooking(null);
                      setNoticeMessage(null);
                    }}
                    type="button"
                    className="p-2.5 text-[#617582] hover:text-[#103b52] rounded-full text-xs transition-colors cursor-pointer"
                    title="Book another appointment"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              /* Booking Form matching reference */
              <>
                <h3 className="text-[22px] font-bold text-[#103b52] m-0 leading-tight">
                  {lang === 'bn' ? 'অনলাইন অ্যাপয়েন্টমেন্টের অনুরোধ' : 'Online appointment request'}
                </h3>
                <p className="text-[#617582] text-[13px] mt-1 mb-5">
                  {lang === 'bn'
                    ? 'তথ্য পূরণ করুন। আপনার অনুরোধটি WhatsApp-এ পাঠানোর জন্য তৈরি হবে।'
                    : 'Fill in the details. Your request will be prepared for WhatsApp submission.'}
                </p>

                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    {/* Parent Name */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'অভিভাবকের নাম' : 'Parent / Guardian name'}
                      </label>
                      <input
                        required
                        type="text"
                        value={formData.parent}
                        onChange={e => setFormData({ ...formData, parent: e.target.value })}
                        placeholder={lang === 'bn' ? 'আপনার নাম' : 'Your name'}
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all"
                      />
                    </div>

                    {/* Phone Number */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'ফোন নম্বর' : 'Phone number'}
                      </label>
                      <input
                        required
                        type="tel"
                        value={formData.phone}
                        onChange={e => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="10-digit mobile number"
                        pattern="[0-9+\-\s]{10,15}"
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all font-mono"
                      />
                    </div>

                    {/* Child's age */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'শিশুর বয়স' : "Child's age"}
                      </label>
                      <input
                        required
                        type="text"
                        value={formData.age}
                        onChange={e => setFormData({ ...formData, age: e.target.value })}
                        placeholder="e.g. 3 years / 6 months"
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all"
                      />
                    </div>

                    {/* Preferred Date */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'পছন্দের তারিখ (রবি – বৃহঃ)' : 'Preferred date (Sun – Thu)'}
                      </label>
                      <input
                        required
                        type="date"
                        min={todayStr}
                        value={formData.date}
                        onChange={e => setFormData({ ...formData, date: e.target.value })}
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all font-mono"
                      />
                    </div>

                    {/* Shift */}
                    <div className="flex flex-col gap-1.5 sm:col-span-2">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'চেম্বারের সময় শিফট' : 'Preferred Shift'}
                      </label>
                      <select
                        value={formData.shift}
                        onChange={e => setFormData({ ...formData, shift: e.target.value as any })}
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all cursor-pointer"
                      >
                        <option value="morning">Morning Shift (10:00 AM – 02:00 PM)</option>
                        <option value="evening">Evening Shift (05:30 PM – 09:00 PM)</option>
                      </select>
                    </div>

                    {/* Reason for visit */}
                    <div className="flex flex-col gap-1.5 sm:col-span-2">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'দেখানোর কারণ' : 'Reason for visit'}
                      </label>
                      <select
                        value={formData.reason}
                        onChange={e => setFormData({ ...formData, reason: e.target.value })}
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all cursor-pointer"
                      >
                        <option value="Fever, cough and cold">Fever, cough and cold (জ্বর, সর্দি-কাশি)</option>
                        <option value="Routine child vaccination">Routine child vaccination (নিয়মিত টিকাদান)</option>
                        <option value="Growth and development check-up">Growth and development check-up (শারীরিক বৃদ্ধি ও বিকাশ)</option>
                        <option value="Newborn / infant care">Newborn / infant care (নবজাতক ও শিশুর যত্ন)</option>
                        <option value="General pediatric consultation">General pediatric consultation (সাধারণ চিকিৎসা)</option>
                        <option value="Other">Other (অন্যান্য)</option>
                      </select>
                    </div>

                    {/* Additional note */}
                    <div className="flex flex-col gap-1.5 sm:col-span-2">
                      <label className="text-[12px] font-extrabold text-[#526a75]">
                        {lang === 'bn' ? 'অতিরিক্ত তথ্য (ঐচ্ছিক)' : 'Additional note (optional)'}
                      </label>
                      <textarea
                        rows={2}
                        value={formData.note}
                        onChange={e => setFormData({ ...formData, note: e.target.value })}
                        placeholder={lang === 'bn' ? 'সংক্ষেপে আপনার অনুরোধ লিখুন' : 'Briefly describe your request'}
                        className="w-full border border-[#d7e4e7] rounded-[11px] p-3 text-[14px] text-[#183342] bg-[#fbfdfd] outline-none focus:border-[#0d7180] focus:ring-3 focus:ring-[#0d7180]/10 transition-all resize-y"
                      />
                    </div>

                    {/* Submit Button */}
                    <div className="sm:col-span-2 pt-2">
                      <button
                        type="submit"
                        className="w-full inline-flex items-center justify-center gap-2 border-0 rounded-full p-3.5 bg-[#0d7180] hover:bg-[#095d6b] text-white font-bold text-sm cursor-pointer shadow-[0_8px_20px_rgba(13,113,128,0.18)] transition-all hover:-translate-y-0.5"
                      >
                        <span>{lang === 'bn' ? 'অ্যাপয়েন্টমেন্টের অনুরোধ পাঠান →' : 'Send appointment request →'}</span>
                      </button>
                    </div>
                  </div>
                </form>

                <div className="text-[11px] text-[#617582] mt-3">
                  {lang === 'bn'
                    ? 'এটি শুধুমাত্র অনুরোধ, নিশ্চিত বুকিং নয়। জরুরি অবস্থায় এই ফর্ম ব্যবহার করবেন না।'
                    : 'This is a request, not a confirmed booking. Do not use this form for emergencies.'}
                </div>

                {noticeMessage && (
                  <div className="mt-3 p-3 rounded-[10px] bg-[#eaf6f0] text-[#176342] text-[13px] border border-[#c4e8d8]">
                    {noticeMessage}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
