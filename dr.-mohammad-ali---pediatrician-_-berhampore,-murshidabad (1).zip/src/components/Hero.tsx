import React from 'react';
import { DOCTOR_DATA } from '../data/translations';
import { Language } from '../types';
import { Phone, Camera, CheckCircle2, MapPin, Calendar, Award } from 'lucide-react';

interface HeroProps {
  lang: Language;
  onOpenBooking: () => void;
  customPhotoUrl: string | null;
  onOpenPhotoModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  lang,
  onOpenBooking,
  customPhotoUrl,
  onOpenPhotoModal,
}) => {
  // Use the uploaded portrait poster as default photo
  const defaultPhotoUrl = '/assets/aistudio/Essential_Pediatric_Care_Poster_8c4fc669.png';
  const activePhoto = customPhotoUrl || defaultPhotoUrl;

  return (
    <section
      id="home"
      className="relative overflow-hidden py-12 md:py-16"
      style={{
        background:
          'radial-gradient(circle at 82% 18%, #d8efed 0, transparent 32%), linear-gradient(115deg, #f5fafb 0%, #edf6f7 55%, #e9f2f8 100%)',
      }}
    >
      <div className="max-w-[1160px] mx-auto px-5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column (7 cols): Heading, Dual-Language Introduction, Actions */}
          <div className="lg:col-span-7">
            {/* Top eyebrow badge */}
            <div className="inline-flex items-center gap-2 text-[#0d7180] font-extrabold text-xs tracking-[1.8px] uppercase mb-3">
              <span className="w-[25px] h-[2px] bg-[#d9a94b]" />
              <span>
                {lang === 'bn' ? 'শিশুদের স্বাস্থ্য ও পরিচর্যা' : 'Pediatric Healthcare Specialist'}
              </span>
            </div>

            {/* Doctor Name & Headline */}
            <h1 className="text-[32px] sm:text-[42px] lg:text-[48px] font-extrabold leading-[1.12] tracking-[-1.2px] text-[#103b52] mb-4">
              {lang === 'bn' ? (
                <>
                  ডা. মহম্মদ আলি <span className="text-[#0d7180] font-normal text-2xl sm:text-3xl block mt-1">বহরমপুরের শিশু বিশেষজ্ঞ</span>
                </>
              ) : (
                <>
                  Dr. Mohammad Ali <span className="text-[#0d7180] font-normal text-2xl sm:text-3xl block mt-1">Pediatrician in Baharampore</span>
                </>
              )}
            </h1>

            {/* FIRST PARAGRAPH: BOTH ENGLISH & BANGLA AS REQUESTED */}
            <div className="bg-white/90 border border-[#dce8eb] rounded-[22px] p-5 sm:p-6 mb-6 shadow-xs backdrop-blur-xs space-y-4">
              {/* English Section */}
              <div className="relative pl-3 border-l-3 border-[#0d7180]">
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-[#0d7180]/10 text-[#0d7180] text-[11px] font-bold uppercase tracking-wider mb-1.5">
                  <span>English</span>
                </div>
                <p className="text-[14px] sm:text-[15px] text-[#334d5c] leading-relaxed">
                  <strong>Dr. Mohammad Ali</strong> is a Pediatrician in Baharampore with an <strong>MBBS (Cal)</strong>, <strong>MD (Pediatrics)</strong> and <strong>DM (Pediatric Intensive Care)</strong>. He is attached to <strong>Kolkata Medical College and Hospital</strong>. He provides care for newborns, infants, children and adolescents, including treatment for fever, cough and cold, routine vaccination, and growth and development check-ups.
                </p>
              </div>

              {/* Subtle divider */}
              <div className="h-[1px] bg-[#e5eff2]" />

              {/* Bengali Section */}
              <div className="relative pl-3 border-l-3 border-[#d9a94b]">
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-[#d9a94b]/15 text-[#8c671b] text-[11px] font-bold uppercase tracking-wider mb-1.5">
                  <span>বাংলা</span>
                </div>
                <p className="text-[14px] sm:text-[15px] text-[#334d5c] leading-relaxed">
                  বহরমপুরের শিশু বিশেষজ্ঞ <strong>ডা. মহম্মদ আলি</strong> <strong>MBBS (Cal)</strong>, <strong>MD (Pediatrics)</strong> এবং <strong>DM (Pediatric Intensive Care)</strong> ডিগ্রিধারী। তিনি <strong>কলকাতা মেডিকেল কলেজ ও হাসপাতালে</strong> কর্মরত। নবজাতক থেকে কিশোর বয়স পর্যন্ত শিশুদের জ্বর, সর্দি-কাশি ও অন্যান্য সাধারণ রোগের চিকিৎসা, নিয়মিত টিকাদান এবং শারীরিক বৃদ্ধি ও বিকাশের পরীক্ষা তিনি করে থাকেন।
                </p>
              </div>

              {/* Chamber Highlight Notice */}
              <div className="pt-2 text-xs sm:text-[13px] text-[#0d7180] font-semibold flex flex-wrap items-center gap-y-2 gap-x-4 bg-[#edf6f7] p-3 rounded-[14px] border border-[#d2ebe9]">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#0d7180] shrink-0" />
                  <span><strong>চেম্বার:</strong> মিশন মেডিকেল সেন্টার, লালদিঘি, বহরমপুর (Mission Medical Centre, Laldighi)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-[#0d7180] shrink-0" />
                  <span><strong>দিন:</strong> প্রতি রবিবার থেকে বৃহস্পতিবার (Sunday to Thursday)</span>
                </span>
              </div>
            </div>

            {/* Action Buttons: Pill buttons matching reference */}
            <div className="flex flex-wrap items-center gap-3">
              <a
                href="#appointment"
                onClick={e => {
                  e.preventDefault();
                  onOpenBooking();
                }}
                className="inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 bg-[#0d7180] hover:bg-[#095d6b] text-white font-bold text-sm shadow-[0_8px_20px_rgba(13,113,128,0.20)] transition-all hover:-translate-y-0.5 cursor-pointer"
              >
                <span>{lang === 'bn' ? 'অ্যাপয়েন্টমেন্ট নিন →' : 'Request Appointment →'}</span>
              </a>

              <a
                href="#about"
                className="inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 bg-white text-[#103b52] border border-[#dce8eb] hover:bg-[#f7fbfc] font-bold text-sm transition-all hover:-translate-y-0.5"
              >
                <span>{lang === 'bn' ? 'ডাক্তারের বিস্তারিত' : 'Doctor Details'}</span>
              </a>

              <a
                href={`tel:${DOCTOR_DATA.phone.replace(/\s+/g, '')}`}
                className="inline-flex items-center gap-1.5 px-4 py-3 rounded-full bg-white/90 border border-[#dce8eb] text-[#103b52] hover:text-[#0d7180] font-mono font-bold text-xs transition-colors"
                title="Call Chamber"
              >
                <Phone className="w-3.5 h-3.5 text-[#0d7180]" />
                <span>{DOCTOR_DATA.phone}</span>
              </a>
            </div>

            {/* Trust Badges */}
            <div className="flex items-center gap-5 mt-6 text-[#607984] text-xs sm:text-[13px] flex-wrap">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#0d7180]" />
                <span>{lang === 'bn' ? '২০ বছরের ক্লিনিকাল অভিজ্ঞতা' : "20 Years' Clinical Experience"}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#0d7180]" />
                <span>{lang === 'bn' ? 'কলকাতা মেডিকেল কলেজ ও হাসপাতাল' : 'Kolkata Medical College'}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-[#0d7180]" />
                <span>{lang === 'bn' ? 'রবি-বৃহস্পতি চেম্বার' : 'Sun–Thu Regular Chamber'}</span>
              </span>
            </div>
          </div>

          {/* Right Column (5 cols): Arched Doctor Photo Portrait & Floating Clinical Badges */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            {/* Arched Portrait Container with Doctor Photo */}
            <div className="portrait-placeholder relative w-full max-w-[340px] sm:max-w-[370px] min-h-[460px] rounded-[170px_170px_24px_24px] overflow-hidden bg-white border-2 border-[#dce8eb] shadow-[0_20px_50px_rgba(16,59,82,0.12)] p-2">
              <div className="w-full h-full rounded-[162px_162px_18px_18px] overflow-hidden relative group">
                <img
                  src={activePhoto}
                  alt="Dr. Mohammad Ali - Pediatrician in Baharampore"
                  className="w-full h-[450px] object-cover object-top transition-transform duration-500 group-hover:scale-105"
                />

                {/* Gradient overlay at bottom of photo for text clarity */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#103b52] via-[#103b52]/80 to-transparent p-4 text-white pt-10">
                  <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#d9a94b] text-[#103b52] text-[10px] font-extrabold uppercase tracking-wider mb-1">
                    <Award className="w-3 h-3" />
                    <span>20 Years Exp</span>
                  </div>
                  <strong className="text-base font-bold block leading-tight">
                    {lang === 'bn' ? 'ডা. মহম্মদ আলি' : 'Dr. Mohammad Ali'}
                  </strong>
                  <span className="text-[11px] text-emerald-200 block mt-0.5">
                    MBBS (Cal), MD (Pediatrics), DM (PICU)
                  </span>
                  <span className="text-[10px] text-slate-300 block">
                    Kolkata Medical College & Hospital
                  </span>
                </div>

                {/* Change photo button */}
                <button
                  onClick={onOpenPhotoModal}
                  type="button"
                  className="absolute top-4 right-4 px-3 py-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full text-xs flex items-center gap-1.5 cursor-pointer backdrop-blur-xs transition-colors shadow-xs"
                  title="View / Change Photos"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? 'ছবি সমূহ' : 'Photos'}</span>
                </button>
              </div>
            </div>

            {/* Floating Badge 1 (Top Left) */}
            <div className="hidden sm:block absolute -left-4 top-16 bg-white py-3 px-4 rounded-[16px] shadow-[0_18px_40px_rgba(18,59,78,0.12)] text-xs font-bold text-[#103b52] border border-[#dce8eb] pointer-events-none animate-bounce-slow">
              <span className="text-[#0d7180] font-black">✚</span>{' '}
              <span>{lang === 'bn' ? 'শিশু রোগ বিশেষজ্ঞ' : 'Pediatric Care'}</span>
              <em className="block text-[#617582] not-italic font-normal text-[11px] mt-0.5">
                {lang === 'bn' ? 'নবজাতক থেকে কিশোর' : 'Newborn to Adolescent'}
              </em>
            </div>

            {/* Floating Badge 2 (Bottom Right) */}
            <div className="hidden sm:block absolute -right-2 bottom-10 bg-white py-3 px-4 rounded-[16px] shadow-[0_18px_40px_rgba(18,59,78,0.12)] text-xs font-bold text-[#103b52] border border-[#dce8eb] pointer-events-none">
              <span className="text-[#0d7180] font-black">♡</span>{' '}
              <span>{lang === 'bn' ? 'লালদিঘি চেম্বার' : 'Laldighi Chamber'}</span>
              <em className="block text-[#617582] not-italic font-normal text-[11px] mt-0.5">
                {lang === 'bn' ? 'রবি থেকে বৃহস্পতি' : 'Sunday to Thursday'}
              </em>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
