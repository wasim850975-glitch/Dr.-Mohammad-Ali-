import React from 'react';
import { DOCTOR_DATA } from '../data/translations';
import { Language } from '../types';

interface FooterProps {
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  return (
    <footer className="bg-[#0b2f42] text-[#d7e7eb] pt-11 pb-7 border-t border-[#1d4356]">
      <div className="max-w-[1160px] mx-auto px-5">
        <div className="flex justify-between items-start gap-7 flex-wrap">
          {/* Doctor Info */}
          <div className="max-w-[480px]">
            <strong className="text-white text-base block mb-1">
              {lang === 'bn' ? DOCTOR_DATA.nameBn : DOCTOR_DATA.name}
            </strong>
            <p className="text-[13px] text-[#a9c1c8] leading-relaxed m-0">
              {lang === 'bn'
                ? 'শিশু বিশেষজ্ঞ · মিশন মেডিকেল সেন্টার, লালদিঘি, বহরমপুর, মুর্শিদাবাদ (রবিবার থেকে বৃহস্পতিবার)। এই ওয়েবসাইটে ক্লিনিকের সাধারণ তথ্য ও অ্যাপয়েন্টমেন্টের অনুরোধের সুবিধা রয়েছে।'
                : 'Pediatrician · Mission Medical Centre, Laldighi, Baharampore, Murshidabad (Sunday to Thursday). This website provides clinic information and appointment requests.'}
            </p>
          </div>

          {/* Important Notice */}
          <div className="max-w-[460px]">
            <strong className="text-white text-sm block mb-1">
              {lang === 'bn' ? 'জরুরি বিজ্ঞপ্তি' : 'Important notice'}
            </strong>
            <p className="text-[13px] text-[#a9c1c8] leading-relaxed m-0">
              {lang === 'bn'
                ? 'ওয়েবসাইটের তথ্য চিকিৎসকের সরাসরি পরামর্শের বিকল্প নয়। জরুরি অবস্থায় অবিলম্বে নিকটস্থ হাসপাতালে চিকিৎসা নিন।'
                : 'Website content is not a substitute for professional medical advice. In an emergency, seek immediate medical care.'}
            </p>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-[#315365] mt-7 pt-4 text-[11px] text-[#a9c1c8] flex flex-col sm:flex-row items-center justify-between gap-2">
          <div>
            © {new Date().getFullYear()} {DOCTOR_DATA.name}. All rights reserved.
          </div>
          <div>
            Mission Medical Centre, Laldighi, Baharampore, Murshidabad – 742101
          </div>
        </div>
      </div>
    </footer>
  );
};
