import React from 'react';
import { Language } from '../types';

interface StatsSectionProps {
  lang: Language;
}

export const StatsSection: React.FC<StatsSectionProps> = ({ lang }) => {
  return (
    <section className="py-12 bg-white border-b border-[#dce8eb]">
      <div className="max-w-[1160px] mx-auto px-5">
        {/* 4 Clean Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="p-6 border border-[#dce8eb] rounded-[20px] bg-gradient-to-b from-white to-[#f7fbfc] text-center hover:border-[#0d7180]/40 transition-colors shadow-xs">
            <strong className="text-[30px] text-[#0d7180] font-bold block leading-tight font-mono">
              20+
            </strong>
            <span className="text-[13px] text-[#56707c] block mt-1 font-semibold">
              {lang === 'bn' ? 'বছরের অভিজ্ঞতা' : 'Years Experience'}
            </span>
            <span className="text-[11px] text-[#869da7] block">
              {lang === 'bn' ? 'শিশু চিকিৎসা ও যত্ন' : 'Pediatric Healthcare'}
            </span>
          </div>

          <div className="p-6 border border-[#dce8eb] rounded-[20px] bg-gradient-to-b from-white to-[#f7fbfc] text-center hover:border-[#0d7180]/40 transition-colors shadow-xs">
            <strong className="text-[24px] sm:text-[26px] text-[#0d7180] font-bold block leading-tight">
              MBBS (Cal)
            </strong>
            <span className="text-[13px] text-[#56707c] block mt-1 font-semibold">
              {lang === 'bn' ? 'কলকাতা বিশ্ববিদ্যালয়' : 'Calcutta University'}
            </span>
            <span className="text-[11px] text-[#869da7] block">
              {lang === 'bn' ? 'মেডিকেল ডিগ্রি' : 'Medical Degree'}
            </span>
          </div>

          <div className="p-6 border border-[#dce8eb] rounded-[20px] bg-gradient-to-b from-white to-[#f7fbfc] text-center hover:border-[#0d7180]/40 transition-colors shadow-xs">
            <strong className="text-[24px] sm:text-[26px] text-[#0d7180] font-bold block leading-tight">
              MD & DM
            </strong>
            <span className="text-[13px] text-[#56707c] block mt-1 font-semibold">
              {lang === 'bn' ? 'শিশু নিবিড় পরিচর্যা' : 'Pediatric Intensive Care'}
            </span>
            <span className="text-[11px] text-[#869da7] block">
              {lang === 'bn' ? 'সুপার স্পেশালিটি (PICU)' : 'Super-Specialty (PICU)'}
            </span>
          </div>

          <div className="p-6 border border-[#dce8eb] rounded-[20px] bg-gradient-to-b from-white to-[#f7fbfc] text-center hover:border-[#0d7180]/40 transition-colors shadow-xs">
            <strong className="text-[22px] sm:text-[24px] text-[#0d7180] font-bold block leading-tight">
              Kolkata Medical
            </strong>
            <span className="text-[13px] text-[#56707c] block mt-1 font-semibold">
              {lang === 'bn' ? 'কলেজ ও হাসপাতাল' : 'College & Hospital'}
            </span>
            <span className="text-[11px] text-[#869da7] block">
              {lang === 'bn' ? 'হাসপাতালে সংযুক্ত' : 'Hospital Attachment'}
            </span>
          </div>
        </div>

        {/* Doctor's Credentials Landscape Banner from provided assets */}
        <div className="rounded-[22px] overflow-hidden border border-[#dce8eb] shadow-sm hover:shadow-md transition-shadow bg-white">
          <img
            src="/assets/aistudio/pediatrician_variant_3_c49ec288.png"
            alt="Dr. Mohammad Ali - Pediatrician Credentials Banner: MBBS (Cal), MD Pediatric, DM Pediatric Intensive Care, Experience 20 Years"
            className="w-full h-auto object-cover max-h-[340px]"
          />
        </div>
      </div>
    </section>
  );
};
