import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { StatsSection } from './components/StatsSection';
import { AboutDoctor } from './components/AboutDoctor';
import { ServicesSection } from './components/ServicesSection';
import { BookingSection } from './components/BookingSection';
import { ChamberLocation } from './components/ChamberLocation';
import { Footer } from './components/Footer';
import { DoctorPhotoModal } from './components/DoctorPhotoModal';
import { Language } from './types';
import { MessageCircle } from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [customPhotoUrl, setCustomPhotoUrl] = useState<string | null>(null);

  const toggleLang = () => {
    setLang(prev => (prev === 'en' ? 'bn' : 'en'));
  };

  const scrollToBooking = () => {
    const el = document.getElementById('appointment');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#183342] flex flex-col font-sans antialiased selection:bg-[#d8efed] selection:text-[#0d7180]">
      {/* Topbar & Sticky Navigation matching reference template */}
      <Navbar
        lang={lang}
        onToggleLang={toggleLang}
        onOpenBooking={scrollToBooking}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          lang={lang}
          onOpenBooking={scrollToBooking}
          customPhotoUrl={customPhotoUrl}
          onOpenPhotoModal={() => setIsPhotoModalOpen(true)}
        />

        {/* Stats Section matching reference */}
        <StatsSection lang={lang} />

        {/* About Section matching reference */}
        <AboutDoctor
          lang={lang}
          onOpenBooking={scrollToBooking}
        />

        {/* Services Section matching reference */}
        <ServicesSection
          lang={lang}
          onOpenBooking={scrollToBooking}
        />

        {/* Appointment / Booking Section matching reference */}
        <BookingSection
          lang={lang}
        />

        {/* Chamber Contact & Google Maps matching reference */}
        <ChamberLocation
          lang={lang}
        />
      </main>

      {/* Footer matching reference */}
      <Footer lang={lang} />

      {/* Doctor Photo Modal */}
      <DoctorPhotoModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        lang={lang}
        customPhotoUrl={customPhotoUrl}
        onSetPhotoUrl={setCustomPhotoUrl}
      />

      {/* Signature Sticky WhatsApp Pill matching reference (.sticky-wa) */}
      <a
        href="https://wa.me/919093964188"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed right-5 bottom-5 z-40 rounded-full bg-[#168b58] hover:bg-[#126b44] text-white py-3 px-4 sm:px-5 font-extrabold text-xs sm:text-sm shadow-[0_8px_25px_rgba(18,75,55,0.25)] flex items-center gap-2 transition-all hover:scale-105"
        title="WhatsApp +91 9093964188"
      >
        <MessageCircle className="w-4 h-4 fill-white text-white" />
        <span>WhatsApp</span>
      </a>
    </div>
  );
}
